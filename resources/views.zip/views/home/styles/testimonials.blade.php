<style>
    #testimonials {
        /*background: linear-gradient(to bottom, rgba(255, 255, 255, 1) 0%, rgba(13, 13, 13, 1) 100%);*/
    }

    .content.testimonials {
        position: relative;
        width: 100%;
        height: 100vh;
        display: flex;
        gap: 1rem;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        text-align: center;
    }

    .content.testimonials img {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .card-testimonial {
        position: absolute;
        width: auto;
        min-height: 100px;
        max-height: 150px;
        padding: 15px;
        box-shadow: 20px 20px 50px rgba(0, 0, 0, 0.5);
        background: rgba(255, 255, 255, 0.1);
        border-radius: 10px;
        box-shadow: 5px 5px 15px rgba(0, 0, 0, 0.2);
        transform: rotate(var(--rotate));
    }

    .text-testimonial p {
        margin: 0;
        color: rgba(0,0,0,1);
        text-align: start;
        font-size: 1.35rem;
    }

    .name-testimonial {
        display: flex;
        gap: 0.85rem;
        align-items: center;
        padding-top: 0.65rem;
    }

    .name-testimonial span {
        color: var(--neutral-gray);
    }

    .name-testimonial span {
        display: block;
        font-size: 1.15rem;
        font-weight: bold;
        margin-top: 8px;
    }

    .name-testimonial .containerImageTestimonial {
        position: relative;
        width: 50px;
        height: 50px;
        border-radius: 50%;
        overflow: hidden;
    }

    .image-testimonial {
        position: relative;
        width: 50px;
        height: 50px;
    }

    .image-testimonial.woman {
        position: absolute;
        bottom: -20px;
        width: 15vw;
        height: 30vh;
        border-radius: var(--border-radius);
        overflow: hidden;
        transform: rotate(19deg);
    }

    .image-testimonial img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .card-testimonial:nth-child(1) { top: 10%; left: 5%; --rotate: -5deg; }
    .card-testimonial:nth-child(2) { top: 10%; right: 5%; --rotate: 5deg; }
    .card-testimonial:nth-child(3) { bottom: 10%; left: 5%; --rotate: -3deg; }
    .card-testimonial:nth-child(4) { bottom: 10%; right: 5%; --rotate: 4deg; }
        
    @media (max-width: 600px) {
        .card-testimonial {
            position: relative;
            width: auto;
            max-width: 80%;
            margin: 10px auto;
            transform: none;
        }

        .card-testimonial:nth-child(2),
        .card-testimonial:nth-child(3),
        .image-testimonial.woman {
            display: none;
        }

        .card-testimonial:nth-child(1) { top: 0; left: 5%; --rotate: -5deg; }
        .card-testimonial:nth-child(4) { bottom: -20px; right: 5%; --rotate: 4deg; }
    }
</style>