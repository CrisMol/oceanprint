@extends('layouts.app')

@push('styles')
    @include('shop.styles.order-confirmation')
@endpush

@section('content')
    <main class="pt-90">
        <div class="mb-4 pb-4"></div>
        <section class="shop-checkout container">
            <h2 class="page-title">Pedido Recibido</h2>
            <div class="order-complete">
                <div class="order-complete__message">
                    <svg width="80" height="80" viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="40" cy="40" r="40" fill="#6EC1E4" />
                    <path
                        d="M52.9743 35.7612C52.9743 35.3426 52.8069 34.9241 52.5056 34.6228L50.2288 32.346C49.9275 32.0446 49.5089 31.8772 49.0904 31.8772C48.6719 31.8772 48.2533 32.0446 47.952 32.346L36.9699 43.3449L32.048 38.4062C31.7467 38.1049 31.3281 37.9375 30.9096 37.9375C30.4911 37.9375 30.0725 38.1049 29.7712 38.4062L27.4944 40.683C27.1931 40.9844 27.0257 41.4029 27.0257 41.8214C27.0257 42.24 27.1931 42.6585 27.4944 42.9598L33.5547 49.0201L35.8315 51.2969C36.1328 51.5982 36.5513 51.7656 36.9699 51.7656C37.3884 51.7656 37.8069 51.5982 38.1083 51.2969L40.385 49.0201L52.5056 36.8996C52.8069 36.5982 52.9743 36.1797 52.9743 35.7612Z"
                        fill="white" />
                    </svg>
                    <h3>¡Tu pedido ha sido completado!</h3>
                    <p>Gracias. Hemos recibido tu pedido correctamente.</p>
                </div>

                <div class="order-info">
                    <div class="order-info__item">
                        <label>Número de pedido</label>
                        <span>{{ str_pad($order->id, 10, '0', STR_PAD_LEFT) }}</span>
                        </div>
                        <div class="order-info__item">
                        <label>Fecha</label>
                        <span>{{ $order->created_at }}</span>
                    </div>
                    <div class="order-info__item">
                        <label>Total</label>
                        <span>${{ number_format($order->total) }}</span>
                    </div>
                </div>

                <div class="checkout__totals-wrapper">
                    <div class="checkout__totals">
                    <h3>Detalles del pedido</h3>
                    <table class="checkout-cart-items">
                        <thead>
                        <tr>
                            <th>PRODUCTO</th>
                            <th>SUBTOTAL</th>
                        </tr>
                        </thead>
                        <tbody>
                            @foreach ($order->orderItems as $item)
                                <tr>
                                    <td>
                                        {{ $item->variation_name }}
                                    </td>
                                    <td>
                                        ${{ $item->price }}
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>

                    <table class="checkout-totals">
                        <tbody>
                            <tr>
                                <th>SUBTOTAL</th>
                                <td>${{ $order->subtotal }}</td>
                            </tr>
                            <tr>
                                <th>ENVÍO</th>
                                <td>Envío gratuito</td>
                            </tr>
                            <tr>
                                <th>TOTAL</th>
                                <td>${{ $order->total }}</td>
                            </tr>
                        </tbody>
                    </table>
                    </div>
                </div>

                @php
                    $url = "https://api.whatsapp.com/send?phone=593962330296&text=";
                    $message = urlencode(
                        "Hola, deseo completar el pago de mi pedido.\n".
                        "🧾 Pedido: " . str_pad($order->id, 10, '0', STR_PAD_LEFT) . "\n" .
                        "💵 Total: $" . number_format($order->total) . "\n\n".
                        "Puedo enviar la foto del comprobante de transferencia o solicitar otro método de pago. Gracias."
                    );
                @endphp

                <div class="container-button">
                    <a
                        href="{{ $url . $message }}"
                        target="_blank"
                        class="btn btn-success btn-pay"
                    >
                        Completar pago por WhatsApp
                    </a>
                </div>

                <div class="order-info__item">
                    <label>Método de pago</label>
                    <span>Transferencia bancaria directa</span>
                </div>
                <div class="image-accounts-container">
                    <img 
                        class="image-accounts"
                        src="{{ asset('images/tienda/cuentas-bancarias-ocean-print.webp') }}" 
                        alt="Cuentas bancarias Ocean print"
                        width="1080"
                    >
                </div>
            </div>
        </section>
    </main>
@endsection