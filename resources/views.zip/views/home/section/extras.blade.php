<div class="extras-content">
    <div class="column carousel-image">
        <div class="carousel-image-content">
            <div class="content-images">
                <img src="{{ asset('images/extras/kit-personalizado-mediplus.jpg') }}" alt="imprenta" width="600" height="600">
                <img src="{{ asset('images/extras/imprenta-2.jpg') }}" alt="imprenta" width="600" height="600">
                <img src="{{ asset('images/extras/imprenta-3.jpeg') }}" alt="imprenta" width="600" height="600">
            </div>
            <div class="contents-description">
                <span>Soluciones integrales</span>
            </div>
        </div>
    </div>
    <div class="column">
        <div class="content-column">
            <div class="content-description blue scroll-reveal-text">
                <h4>Generación de marca</h4>
                <p>
                    <span>Desarrollo de productos con tu identidad corporativa para que cada cliente genera un recuerdo de marca</span>
                </p>
            </div>
            <div class="content-image">
                <img src="{{ asset('images/extras/generacion-de-marca.webp') }}" alt="Generacion de marca, varios productos Ocean print" width="350" height="350"  loading="lazy">
            </div>
        </div>
    </div>
    <div class="column">
        <div class="content-column">
            <div class="content-image order-2">
                <img src="{{ asset('images/extras/cuerpo-de-bomberos-benemerito.webp') }}" alt="Cuerpo de bomberos Benémerito Ocean print" width="350" height="350" loading="lazy">
            </div>
            <div class="content-description soft-pink scroll-reveal-text order-1">
                <h4>Nuevos desarrollos de mercado</h4>
                <p>
                    <span>
                    Nos mantenemos a la vanguardia con nuevos desarrollos del mercado para ofrecerte soluciones de impresión innovadoras, eficientes y de alta calidad.
                    </span>
                </p>
            </div>
        </div>
    </div>
    <div class="column">
        <div class="content-column">
            <div class="content-description calm-turquoise scroll-reveal-text">
                <h4>Productos reciclajes</h4>
                <p>
                    <span>Utilizamos productos reciclados para reducir el impacto ambiental y promover una impresión más responsable.</span>
                </p>
            </div>
            <div class="content-image">
                <img src="{{ asset('images/extras/bomberos-provincia-santa-elena.webp') }}" alt="Cuerpo de bomberos Provincia de Santa Elena" width="350" height="350" loading="lazy">
            </div>
        </div>
    </div>
</div>